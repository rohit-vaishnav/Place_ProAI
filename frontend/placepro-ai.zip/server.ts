import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Gemini safely
let ai: GoogleGenAI | null = null;
const apiKey = process.env.GEMINI_API_KEY;

if (apiKey) {
  try {
    ai = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
    console.log("Gemini client successfully initialized.");
  } catch (error) {
    console.error("Failed to initialize Gemini client:", error);
  }
} else {
  console.warn("GEMINI_API_KEY is not defined in the environment. API endpoints will use fallback simulation mode.");
}

// Help helper to call Gemini
async function getGeminiResponse(prompt: string, expectJson = false, systemInstruction = "") {
  if (!ai) {
    throw new Error("Gemini AI client is not initialized.");
  }

  const response = await ai.models.generateContent({
    model: "gemini-3.5-flash",
    contents: prompt,
    config: {
      systemInstruction: systemInstruction || undefined,
      responseMimeType: expectJson ? "application/json" : "text/plain",
    }
  });

  return response.text;
}

// ----------------------------------------------------
// API ROUTES
// ----------------------------------------------------

// 1. Health check
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", geminiConfigured: !!ai });
});

// 2. Resume Analyzer API
app.post("/api/gemini/analyze-resume", async (req, res) => {
  const { resumeText, jobDescription, candidateCoreInfo } = req.body;
  if (!resumeText) {
    return res.status(400).json({ error: "resumeText is required." });
  }

  const jdText = jobDescription || "Any general software development, engineering, or non-technical business internship / job roles";

  const systemInstruction = `You are an veteran Corporate Recruitment Specialist and ATS Automated Screener. 
Analyze the provided resume against the given Job Description and output a detailed analysis in valid structured JSON ONLY.
Ensure accuracy, direct, professional language and extremely helpful skill gap evaluations.`;

  const prompt = `Analyze this resume against the job description below:

--- RESUME TEXT / PROFILE INFO ---
${resumeText}
${candidateCoreInfo ? `Candidate Academics/Info: ${JSON.stringify(candidateCoreInfo)}` : ""}

--- Target JOB DESCRIPTION ---
${jdText}

Return a JSON object with this exact typescript schema:
{
  "atsScore": number (0-100),
  "resumeScore": number (0-100),
  "readinessRating": "Poor" | "Needs Improvement" | "Good" | "Excellent" | "Hire",
  "skillGapAnalysis": {
    "detectedSkills": string[],
    "missingCriticalSkills": string[],
    "goodToHaveMissing": string[]
  },
  "improvementSuggestions": {
    "formatting": string[],
    "keywords": string[],
    "experienceImpact": string[]
  },
  "industryReadinessSummary": string (concise 2-3 sentence overview)
}`;

  try {
    if (ai) {
      const responseText = await getGeminiResponse(prompt, true, systemInstruction);
      if (responseText) {
        return res.json(JSON.parse(responseText.trim()));
      }
    }
    // Grasping a nice fallback if API is not setup
    throw new Error("No response or Gemini client not configured.");
  } catch (err: any) {
    console.error("Resume analysis error:", err.message);
    // Simulate fallback
    const mockScore = Math.floor(Math.random() * 20) + 65; // 65-85
    return res.json({
      atsScore: mockScore,
      resumeScore: mockScore + 3,
      readinessRating: mockScore > 80 ? "Excellent" : "Good",
      skillGapAnalysis: {
        detectedSkills: ["React", "TypeScript", "Tailwind CSS", "JavaScript", "HTML/CSS", "Git"],
        missingCriticalSkills: ["Database Design (SQL/NoSQL)", "System Architecture", "Unit Testing (Jest)"],
        goodToHaveMissing: ["Express.js", "Docker", "REST API Development"]
      },
      improvementSuggestions: {
        formatting: [
          "Format experiences with stronger action verbs instead of passive phrases.",
          "Add structured sections for Certifications and Links (GitHub, LinkedIn)."
        ],
        keywords: [
          "Incorporate terms like 'API Integration', 'Full-Stack Development', and 'Responsive Web Design' to pass automated ATS filters."
        ],
        experienceImpact: [
          "Quantify statements where possible (e.g. 'Improved loading speed by 25%' rather than simply 'Optimized pages')."
        ]
      },
      industryReadinessSummary: "The candidate demonstrates solid fundamental knowledge in front-end development using modern React and TypeScript. To become fully industry-ready, strengthening backend frameworks (like NestJS/Express) and relational database integration is highly recommended."
    });
  }
});

// 3. Career Chatbot API
app.post("/api/gemini/chatbot", async (req, res) => {
  const { messages, userRole, currentTab } = req.body;
  if (!messages || !Array.isArray(messages)) {
    return res.status(400).json({ error: "messages array is required." });
  }

  // Construct chat history limit for system instructions
  const systemInstruction = `You are the AI Career Assistant for the Placement & Internship Management Platform.
You help college students with career guidance, resume suggestions, interview preparation roadmaps, and helpful campus placement tips. 
If the user is a Recruiter or Placement Officer, change your context to support their workflow (e.g. draft job descriptions, suggest ideal filtering criteria).
Keep your advice clear, encouraging, structured in elegant Markdown, and professional. Current user role: ${userRole || "student"}. Current platform tab: ${currentTab || "general"}.`;

  // Map messages to Gemini SDK contents format or construct a prompt
  const messageHistory = messages.map(m => `${m.role === 'user' ? 'User' : 'Assistant'}: ${m.content}`).join("\n");
  const prompt = `Here is the conversation history:\n${messageHistory}\n\nRespond to the latest query as the AI Career Assistant:`;

  try {
    if (ai) {
      const responseText = await getGeminiResponse(prompt, false, systemInstruction);
      if (responseText) {
        return res.json({ content: responseText });
      }
    }
    throw new Error("No response or Gemini client not configured.");
  } catch (err: any) {
    console.error("Chatbot error:", err.message);
    // Generic simulated responses based on latest user text
    const lastMsg = messages[messages.length - 1]?.content?.toLowerCase() || "";
    let reply = "I would be happy to help you prepare! कैंपस प्लेसमेंट के लिए continuous mock practice, DSA foundations, and core projects are very important. What specific topic should we focus on first?";
    if (lastMsg.includes("resume") || lastMsg.includes("cv")) {
      reply = "For an excellent student resume:\n1. Keep it to a **single page**.\n2. Put **Skills and Core Projects** near the top.\n3. Write bullet points with standard STAR format: *Situation, Task, Action, Result*.\n4. Avoid generic objective statements—use a brief professional summary instead. Would you like me to scan your skills and suggest additions?";
    } else if (lastMsg.includes("interview") || lastMsg.includes("mock")) {
      reply = "Preparing for interviews consists of three parts:\n- **Technical**: core concepts (OOP, DBMS, Networks, Data Structures & Algorithms).\n- **Behavioral**: explaining project challenges, managing deadlines, resolving team conflicts (STAR format).\n- **HR / Background**: self-introduction, describing why you want to join. Let's start a mock interview right here or use the special **AI Mock Interview** screen!";
    } else if (lastMsg.includes("job") || lastMsg.includes("internship")) {
      reply = "To land high-paying internships:\n- Create **2-3 real-world full-stack or mobile projects** in Git.\n- Master the core technical stack of your target role (e.g. React, Node, SQL for Web).\n- Ensure your campus placement profile is **Verified** by your Placement Officer.";
    }
    return res.json({ content: reply });
  }
});

// 4. Mock Interview Question Generation API
app.post("/api/gemini/mock-interview/generate-questions", async (req, res) => {
  const { jobTitle, jobDescription, roundType } = req.body;
  const title = jobTitle || "Software Engineer Intern";
  const desc = jobDescription || "Familiarity with JS/TS, building single page apps, debugging backend services, collaborative teamwork.";
  const round = roundType || "Technical";

  const systemInstruction = `You are an expert AI interviewer generating original, thoughtful mock interview questions. 
Generate 5 distinct, highly relevant open-ended interview questions corresponding specifically to the job role, description, and chosen interview round focus (Technical, HR, or Behavioral). 
Output absolutely legal structured JSON ONLY.`;

  const prompt = `Generate exactly 5 interview questions for a ${round} Round interview.
Role Title: ${title}
Brief Description: ${desc}

Output a valid JSON array of objects, with each object matching this structure exactly:
{
  "id": number (1 to 5),
  "question": string (original, challenging question suitable for students),
  "conceptsTested": string (short description of what this question tests)
}`;

  try {
    if (ai) {
      const responseText = await getGeminiResponse(prompt, true, systemInstruction);
      if (responseText) {
        return res.json(JSON.parse(responseText.trim()));
      }
    }
    throw new Error("No response or Gemini client not configured.");
  } catch (err: any) {
    console.error("Question generation error:", err.message);
    const fallbackMap: Record<string, { id: number; question: string; conceptsTested: string }[]> = {
      "Technical": [
        { id: 1, question: "Explain the difference between state and props in React. When would you prefer state over props?", conceptsTested: "React fundamentals" },
        { id: 2, question: "What is Event Loop in JavaScript, and how does it support asynchronous non-blocking I/O operations?", conceptsTested: "JS Engine and Asynchronous execution" },
        { id: 3, question: "How do you ensure proper security (like avoiding SQL injection) in your backend APIs?", conceptsTested: "Security best practices" },
        { id: 4, question: "Explain how you would optimize a slow page load in a React SPA using Vite.", conceptsTested: "Performance and Bundler optimization" },
        { id: 5, question: "Can you walk us through a time you had to select a data structure (e.g. Map vs Object) to solve a specific development challenge?", conceptsTested: "Practical DSA usage" }
      ],
      "HR": [
        { id: 1, question: "Tell me about yourself and why you chose to apply for this specific role and organization.", conceptsTested: "Self-expression and motivation" },
        { id: 2, question: "Where do you see yourself professionally in the next three to five years?", conceptsTested: "Career planning and alignment" },
        { id: 3, question: "What do you consider your biggest professional or academic strength, and conversely, one area you are actively looking to improve?", conceptsTested: "Self-awareness" },
        { id: 4, question: "Why should we hire you over other qualified candidates from your batch?", conceptsTested: "Value proposition" },
        { id: 5, question: "Do you have any questions for the management about our company culture or future direction?", conceptsTested: "Engagement and curiosity" }
      ],
      "Behavioral": [
        { id: 1, question: "Describe a complex team project where a conflict came up between members. How did you handle it?", conceptsTested: "Conflict resolution and collaboration" },
        { id: 2, question: "Tell me about a time when a critical bug occurred close to a release deadline. How did you act?", conceptsTested: "Pressure handling and prioritisation" },
        { id: 3, question: "Give an example of a situation where you had to learn a completely new technology or tool in a very short span of time. What was your approach?", conceptsTested: "Adaptability and learning mindset" },
        { id: 4, question: "Tell me about a time you made a mistake on an assignment or project. How did you communicate this to your group and rectify it?", conceptsTested: "Accountability and communication" },
        { id: 5, question: "Explain a scenario where you had to lead a group project. How did you delegate tasks to ensure success?", conceptsTested: "Leadership and organization" }
      ]
    };
    return res.json(fallbackMap[round] || fallbackMap["Technical"]);
  }
});

// 5. Mock Interview Answer Evaluation API
app.post("/api/gemini/mock-interview/evaluate", async (req, res) => {
  const { jobTitle, roundType, qnas } = req.body;
  if (!qnas || !Array.isArray(qnas)) {
    return res.status(400).json({ error: "qnas array is required." });
  }

  const systemInstruction = `You are an expert AI Recruiting Interview panelist. 
Evaluate the candidate's answers corresponding to each of the mock interview questions.
Provide a high-quality, comprehensive assessment report in structured JSON format ONLY. 
Provide realistic ratings and helpful actionable feedback.`;

  const prompt = `Evaluate code role: ${jobTitle || "Software Developer Intern"}
Round Type: ${roundType || "Technical"}

Responses from the Candidate:
${qnas.map((item, idx) => `Question ${idx + 1}: ${item.question}\nAnswer: ${item.answer}`).join("\n\n")}

Evaluate this and return EXACTLY a JSON object with this schema:
{
  "totalScore": number (0-100),
  "grade": "A" | "B" | "C" | "D" | "Fail",
  "readinessVerdict": string,
  "strengths": string[],
  "weaknesses": string[],
  "detailedQnaFeedback": [
    {
      "questionId": number,
      "question": string,
      "candidateAnswer": string,
      "score": number (0-100),
      "pros": string,
      "cons": string,
      "suggestedExcellentModelAnswer": string
    }
  ],
  "actionableTips": string[]
}`;

  try {
    if (ai) {
      const responseText = await getGeminiResponse(prompt, true, systemInstruction);
      if (responseText) {
        return res.json(JSON.parse(responseText.trim()));
      }
    }
    throw new Error("No response or Gemini client not configured.");
  } catch (err: any) {
    console.error("Evaluation error:", err.message);
    const mockFeedbacks = qnas.map((q, idx) => {
      const length = q.answer?.trim().length || 0;
      const score = Math.min(Math.max(Math.floor(length * 0.4) + 40, 50), 95); // simple deterministic mock score
      return {
        questionId: idx + 1,
        question: q.question,
        candidateAnswer: q.answer || "(No Answer Provided)",
        score: score,
        pros: length > 30 ? "Good attempts to explain the conceptual approach and structure." : "Simple baseline understanding displayed.",
        cons: length < 50 ? "Response is too short. Lacks concrete examples or in-depth technical explanation." : "Could structure explanation better using the STAR method.",
        suggestedExcellentModelAnswer: `For '${q.question}', a top tier candidate should define the exact term, provide a relatable real-world example, discuss edge cases, and elaborate on how the concept benefits project performance and maintainability.`
      };
    });

    const averageMockScore = Math.floor(mockFeedbacks.reduce((sum, item) => sum + item.score, 0) / mockFeedbacks.length) || 72;

    return res.json({
      totalScore: averageMockScore,
      grade: averageMockScore > 85 ? "A" : averageMockScore > 70 ? "B" : averageMockScore > 55 ? "C" : qnas.every(q => !q.answer) ? "Fail" : "D",
      readinessVerdict: averageMockScore > 80 ? "Fully prepared for active corporate interview drives. Strong communication." : "Solid foundations but needs critical improvements, especially in detailing technical implementation concepts during mock sessions.",
      strengths: [
        "Covers basic terminology and shows interest.",
        "Quick response turnaround time.",
        "Practical awareness of technical projects."
      ],
      weaknesses: [
        "Inadequate elaboration on advanced structural topics.",
        "Missing situational references like past project hurdles.",
        "Short, simplified definitions."
      ],
      detailedQnaFeedback: mockFeedbacks,
      actionableTips: [
        "Practice speaking answers out loud to refine fluency.",
        "Use the STAR model (Situation, Task, Action, Result) for all response types.",
        "Spend extra focus revising Core engineering fundamentals like OOP principles and browser optimization."
      ]
    });
  }
});

// 6. AI Candidate Ranking API
app.post("/api/gemini/rank-candidates", async (req, res) => {
  const { jobRequirements, candidates } = req.body;
  if (!candidates || !Array.isArray(candidates)) {
    return res.status(400).json({ error: "candidates array is required." });
  }

  const systemInstruction = `You are an AI Recruitment Evaluator. 
Compare multiple candidate profiles against the job requirements and rank them from best fit to lowest fit. 
Format your final output as valid structured JSON ONLY.`;

  const prompt = `Rank these candidate profiles according to fit for this role:
Job Requirements: ${jobRequirements || "General Software Engineer (Web development, database, and system speed, React, Node)"}

Profiles to compare:
${candidates.map((c, i) => `Candidate #${i + 1} (${c.name}):
- Skills: ${c.skills?.join(", ") || "None"}
- Resume Score: ${c.resumeScore || 0}
- Mock Interview Score: ${c.interviewScore || 0}
- Verification Status: ${c.verified ? "Verified by College" : "Pending Verification"}
- Academic GPA / CGPA: ${c.gpa || "N/A"}`).join("\n\n")}

Return exactly a JSON array of objects representing the ranked positions:
[
  {
    "rank": number (1, 2, 3, etc.),
    "name": string (candidate name matching input),
    "matchScore": number (0-100 indicating percentage eligibility fit),
    "keyReason": string (brief, professional description of why they placed here),
    "recommendedRoles": string[] (appropriate sub-focuses)
  }
]`;

  try {
    if (ai) {
      const responseText = await getGeminiResponse(prompt, true, systemInstruction);
      if (responseText) {
        return res.json(JSON.parse(responseText.trim()));
      }
    }
    throw new Error("No response or Gemini client not configured.");
  } catch (err: any) {
    console.error("Evaluation error:", err.message);
    // Dynamic ranking mock fallback
    const mockRankings = [...candidates]
      .map(c => {
        const resumeMetric = c.resumeScore || 70;
        const interviewMetric = c.interviewScore || 70;
        const gpaMetric = parseFloat(c.gpa) ? parseFloat(c.gpa) * 10 : 75;
        const bonus = c.verified ? 5 : 0;
        const totalFit = Math.min(Math.floor((resumeMetric + interviewMetric + gpaMetric) / 3) + bonus, 100);
        return {
          name: c.name,
          matchScore: totalFit,
          skills: c.skills || []
        };
      })
      .sort((a, b) => b.matchScore - a.matchScore)
      .map((item, idx) => ({
        rank: idx + 1,
        name: item.name,
        matchScore: item.matchScore,
        keyReason: `Demonstrates ${item.matchScore > 85 ? 'industry-leading' : 'strong standard'} skill matching across target requirements. Skills in ${item.skills.slice(0,3).join(', ')} align with immediate project layouts.`,
        recommendedRoles: idx === 0 ? ["Full Stack Lead", "Senior Web Developer"] : ["Web Engineer", "Associate Front-End Specialist"]
      }));

    return res.json(mockRankings);
  }
});


// ----------------------------------------------------
// VITE OR STATIC SERVING MIDDLEWARE
// ----------------------------------------------------

async function serveApp() {
  if (process.env.NODE_ENV !== "production") {
    // Development Mode
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
    console.log("Vite development server middleware loaded.");
  } else {
    // Production Mode
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
    console.log(`Static file production serving registered at ${distPath}.`);
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server listening at http://localhost:${PORT}`);
  });
}

serveApp().catch(err => {
  console.error("Uncaught server startup error:", err);
});
