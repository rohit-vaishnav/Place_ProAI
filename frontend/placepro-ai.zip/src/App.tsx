import { useState, useEffect } from "react";
import { 
  Sparkles, Award, Star, Shield, HelpCircle, 
  ArrowRight, CheckCircle2, ChevronRight, Briefcase, GraduationCap, Users,
  Lock, LogOut, ArrowLeftRight, UserCheck, AlertTriangle,
  Home, Menu, X, ChevronDown
} from "lucide-react";
import Logo from "./components/Logo";
import VideoText from "./components/VideoText";
import ShimmerButton from "./components/ShimmerButton";
import StudentPortal from "./components/StudentPortal";
import RecruiterPortal from "./components/RecruiterPortal";
import PlacementOfficerPortal from "./components/PlacementOfficerPortal";
import AdminPortal from "./components/AdminPortal";
import BorderGlow from "./components/BorderGlow";
import AuthPage from "./components/AuthPage";

// Initial seed databases
import { 
  initialStudents, 
  initialJobs, 
  initialApplications, 
  initialDrives, 
  initialMockInterviews 
} from "./data";
import { StudentProfile, Job, Application, PlacementDrive, MockInterviewResult, UserRole } from "./types";

export default function App() {
  const [studentsByState, setStudentsByState] = useState<StudentProfile[]>(() => {
    const saved = localStorage.getItem("placely_students");
    return saved ? JSON.parse(saved) : initialStudents;
  });
  
  const [jobsByState, setJobsByState] = useState<Job[]>(() => {
    const saved = localStorage.getItem("placely_jobs");
    return saved ? JSON.parse(saved) : initialJobs;
  });

  const [applicationsByState, setApplicationsByState] = useState<Application[]>(() => {
    const saved = localStorage.getItem("placely_applications");
    return saved ? JSON.parse(saved) : initialApplications;
  });

  const [drivesByState, setDrivesByState] = useState<PlacementDrive[]>(() => {
    const saved = localStorage.getItem("placely_drives");
    return saved ? JSON.parse(saved) : initialDrives;
  });

  const [mockInterviewsByState, setMockInterviewsByState] = useState<MockInterviewResult[]>(() => {
    const saved = localStorage.getItem("placely_mock_interviews");
    return saved ? JSON.parse(saved) : initialMockInterviews;
  });

  // Role Session state persistence
  const [currentUser, setCurrentUser] = useState<{
    id: string;
    name: string;
    email: string;
    role: UserRole;
    companyName?: string;
  } | null>(() => {
    const saved = localStorage.getItem("placely_cur_user");
    return saved ? JSON.parse(saved) : null;
  });

  const [activePortalIndex, setActivePortalIndex] = useState<number>(0);
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);

  // Synchronize localStorage
  useEffect(() => {
    localStorage.setItem("placely_students", JSON.stringify(studentsByState));
  }, [studentsByState]);

  useEffect(() => {
    localStorage.setItem("placely_jobs", JSON.stringify(jobsByState));
  }, [jobsByState]);

  useEffect(() => {
    localStorage.setItem("placely_applications", JSON.stringify(applicationsByState));
  }, [applicationsByState]);

  useEffect(() => {
    localStorage.setItem("placely_drives", JSON.stringify(drivesByState));
  }, [drivesByState]);

  useEffect(() => {
    localStorage.setItem("placely_mock_interviews", JSON.stringify(mockInterviewsByState));
  }, [mockInterviewsByState]);

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem("placely_cur_user", JSON.stringify(currentUser));
    } else {
      localStorage.removeItem("placely_cur_user");
    }
  }, [currentUser]);

  // Find matches for active student profile
  const loggedInStudent = studentsByState.find(s => s.id === (currentUser?.role === "student" ? currentUser.id : "")) 
    || studentsByState[0] 
    || initialStudents[0];

  // Map gooey navigation indices to core routing state
  const portalRoles = ["home", "student", "recruiter", "officer", "admin"] as const;
  const currentRole = portalRoles[activePortalIndex];

  // Map portal roles to system expectations for alignment screens
  const getRoleLabel = (role: UserRole) => {
    switch(role) {
      case "student": return "Candidate Student";
      case "recruiter": return "Corporate Recruiter";
      case "placementOfficer": return "Placement Officer";
      case "admin": return "System Administrator";
    }
  };

  // Callback: Students management
  const handleUpdateStudentProfile = (editedProfile: StudentProfile) => {
    setStudentsByState(prev => prev.map(s => s.id === editedProfile.id ? editedProfile : s));
  };

  const handleApplyJob = (jobId: string) => {
    // Prevent duplicate entries
    const duplicate = applicationsByState.find(app => app.jobId === jobId && app.studentId === loggedInStudent.id);
    if (duplicate) return;

    const newApp: Application = {
      id: "app_" + Date.now(),
      jobId,
      studentId: loggedInStudent.id,
      studentName: loggedInStudent.name,
      status: "Applied",
      appliedDate: new Date().toISOString().split('T')[0]
    };
    
    setApplicationsByState(prev => [...prev, newApp]);

    // Track statistics: add registered RSVP count on drive matches if company names map
    const targetJob = jobsByState.find(j => j.id === jobId);
    if (targetJob) {
      setDrivesByState(prev => prev.map(d => {
        if (targetJob.recruiterName && d.companyName.toLowerCase().includes(targetJob.recruiterName.toLowerCase())) {
          return { ...d, registeredCount: d.registeredCount + 1 };
        }
        return d;
      }));
    }
  };

  const handleSaveMockInterviewResult = (result: MockInterviewResult) => {
    setMockInterviewsByState(prev => [...prev, result]);
    
    // Auto-update applied application score matching this student's job profile
    setApplicationsByState(prev => prev.map(app => {
      if (app.studentId === result.studentId && result.jobTitle.toLowerCase().includes(app.studentName.toLowerCase())) {
        return {
          ...app,
          status: "Shortlisted",
          interviewScore: result.totalScore
        };
      }
      return app;
    }));
  };

  // Callback: Recruiters management
  const handleCreateJob = (newJob: Job) => {
    setJobsByState(prev => [...prev, newJob]);
  };

  const handleUpdateJob = (editedJob: Job) => {
    setJobsByState(prev => prev.map(j => j.id === editedJob.id ? editedJob : j));
  };

  const handleDeleteJob = (jobId: string) => {
    setJobsByState(prev => prev.filter(j => j.id !== jobId));
  };

  const handleUpdateApplicationStatus = (appId: string, status: any) => {
    setApplicationsByState(prev => prev.map(app => {
      if (app.id === appId) {
        // Carry student mock interview score over to recruiter dashboard if mock assigned
        const resultMockObj = mockInterviewsByState.find(m => m.studentId === app.studentId);
        return {
          ...app,
          status,
          interviewScore: status === "MockAssigned" ? (resultMockObj ? resultMockObj.totalScore : undefined) : app.interviewScore
        };
      }
      return app;
    }));
  };

  // Callback: Placement Officers management
  const handleVerifyStudent = (studentId: string, status: "Verified" | "Rejected", remarks?: string) => {
    setStudentsByState(prev => prev.map(s => s.id === studentId ? { ...s, verificationStatus: status, verificationRemarks: remarks } : s));
  };

  const handleVerifyJob = (jobId: string, status: "Approved" | "Rejected", remarks?: string) => {
    setJobsByState(prev => prev.map(j => j.id === jobId ? { ...j, verificationStatus: status, verificationRemarks: remarks } : j));
  };

  const handleAddDrive = (newDrive: PlacementDrive) => {
    setDrivesByState(prev => [...prev, newDrive]);
  };

  const handleDeleteDrive = (driveId: string) => {
    setDrivesByState(prev => prev.filter(d => d.id !== driveId));
  };

  // Callback: Admin management
  const handleDeleteStudent = (studentId: string) => {
    setStudentsByState(prev => prev.filter(s => s.id !== studentId));
  };

  const handleGrantVerification = (studentId: string) => {
    setStudentsByState(prev => prev.map(s => s.id === studentId ? { ...s, verificationStatus: "Verified" } : s));
  };

  const handleClearCache = () => {
    setStudentsByState(initialStudents);
    setJobsByState(initialJobs);
    setApplicationsByState(initialApplications);
    setDrivesByState(initialDrives);
    setMockInterviewsByState(initialMockInterviews);
    setCurrentUser(null);
    setActivePortalIndex(0);
    localStorage.removeItem("placely_students");
    localStorage.removeItem("placely_jobs");
    localStorage.removeItem("placely_applications");
    localStorage.removeItem("placely_drives");
    localStorage.removeItem("placely_mock_interviews");
    localStorage.removeItem("placely_cur_user");
  };

  const handleAddStudentOnSignup = (newStudent: StudentProfile) => {
    setStudentsByState(prev => {
      const exists = prev.some(s => s.email === newStudent.email || s.id === newStudent.id);
      if (exists) return prev;
      return [...prev, newStudent];
    });
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setActivePortalIndex(0);
  };

  const navItems = [
    { label: "Home Base", id: "home", icon: Home },
    { label: "Student Portal", id: "student", icon: GraduationCap },
    { label: "Corporate Recruiter", id: "recruiter", icon: Briefcase },
    { label: "Placement Officer", id: "officer", icon: Users },
    { label: "Root Admin", id: "admin", icon: Shield }
  ];

  // Map the navigation index to matching UserRole key
  const routeRoleMapping: Record<string, UserRole> = {
    "student": "student",
    "recruiter": "recruiter",
    "officer": "placementOfficer",
    "admin": "admin"
  };

  // Check auth validations
  const isGuest = currentUser === null;
  const isCorrectRole = currentRole === "home" || (currentUser && routeRoleMapping[currentRole] === currentUser.role);

  // Helper avatar colors
  const getUserBgClass = (role: UserRole) => {
    switch(role) {
      case "student": return "bg-emerald-50 text-emerald-800 border-emerald-200";
      case "recruiter": return "bg-[#EEF2FF] text-[#3730A3] border-[#C7D2FE]";
      case "placementOfficer": return "bg-[#FFF1F2] text-[#9F1239] border-[#FECDD3]";
      case "admin": return "bg-[#FFFBEB] text-[#92400E] border-[#FDE68A]";
    }
  };

  return (
    <div className="min-h-screen bg-[#F6F4E8] font-sans text-[#2D3748] selection:bg-[#E5EEE4] selection:text-[#2D3748] pb-16 flex flex-col items-center">
      
      {/* Top Professional Sticky Responsive Header */}
      <header className="w-full sticky top-0 z-50 bg-white/90 backdrop-blur-md border-b border-neutral-200/80 shadow-[0_2px_12px_rgba(45,55,72,0.03)] px-4">
        <div className="w-full max-w-7xl mx-auto py-3 flex items-center justify-between gap-3">
          {/* Logo Section */}
          <Logo showText={true} />
          
          {/* Responsive Desktop Nav Tabs */}
          <nav className="hidden lg:flex items-center gap-1.5 bg-neutral-100 p-1.5 rounded-full border border-neutral-200/60 shadow-inner">
            {navItems.map((item, idx) => {
              const IconComp = item.icon;
              const isActive = activePortalIndex === idx;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActivePortalIndex(idx);
                    setMobileMenuOpen(false);
                  }}
                  className={`flex items-center gap-2 text-xs font-semibold px-4 py-2 rounded-full transition-all duration-200 cursor-pointer ${
                    isActive 
                      ? "bg-[#1E293B] text-white shadow-sm" 
                      : "text-neutral-500 hover:text-neutral-800 hover:bg-neutral-200/50"
                  }`}
                >
                  <IconComp className={`w-3.5 h-3.5 ${isActive ? "text-emerald-400" : "text-neutral-500"}`} />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Current Role Identity Bar, Login Control, & Mobile Menu Button */}
          <div className="flex items-center gap-2 md:gap-3.5">
            {currentUser ? (
              <div className="flex items-center gap-2 bg-neutral-50 pl-2 pr-3 py-1 rounded-full border border-neutral-200/80 shadow-sm max-w-[210px] md:max-w-none">
                <div className={`w-6 h-6 rounded-full border flex items-center justify-center font-bold text-[10px] uppercase tracking-wider shrink-0 ${getUserBgClass(currentUser.role)}`}>
                  {currentUser.name.substring(0, 2)}
                </div>
                <div className="hidden md:flex flex-col text-left">
                  <span className="text-[10px] font-bold text-slate-800 leading-tight">
                    {currentUser.name}
                  </span>
                  <span className="text-[8px] font-mono font-extrabold uppercase text-neutral-400 tracking-wider">
                    {currentUser.role === "recruiter" && currentUser.companyName ? currentUser.companyName : getRoleLabel(currentUser.role)}
                  </span>
                </div>
                <button
                  onClick={handleLogout}
                  title="Sign out transition"
                  className="p-1 text-neutral-400 hover:text-rose-700 hover:bg-rose-50 rounded-full transition shrink-0"
                >
                  <LogOut className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <button
                onClick={() => {
                  setActivePortalIndex(1);
                  setMobileMenuOpen(false);
                }}
                className="flex items-center gap-1 text-[10px] md:text-xs font-mono font-extrabold text-neutral-500 hover:text-neutral-800 bg-white px-2.5 md:px-3.5 py-1.5 md:py-2 border border-neutral-200 shadow-sm rounded-full transition active:scale-95"
              >
                <Lock className="w-3 h-3 text-emerald-750" />
                <span>PORTAL LOGIN</span>
              </button>
            )}

            <div className="hidden lg:flex items-center gap-2 text-[10px] font-mono font-semibold bg-neutral-50 border border-neutral-200/80 px-2.5 py-1.5 rounded-full select-none text-neutral-500">
              <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" />
              <span>{currentRole === 'home' ? 'Main Hub' : `${currentRole} view`}</span>
            </div>

            {/* Mobile / Tablet Menu Hamburger */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-neutral-600 hover:text-neutral-900 bg-neutral-100 hover:bg-neutral-200/80 rounded-xl border border-neutral-200/60 transition active:scale-95 cursor-pointer"
              aria-label="Toggle navigation"
            >
              {mobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Mobile menu dropdown panel */}
        {mobileMenuOpen && (
          <div className="lg:hidden absolute left-0 right-0 top-[100%] bg-white border-b border-neutral-200 shadow-xl px-4 py-4 animate-fade-in flex flex-col gap-2 z-50">
            <span className="text-[9px] font-mono font-extrabold text-neutral-400 uppercase tracking-widest px-2 mb-1">Navigation Portals</span>
            {navItems.map((item, idx) => {
              const IconComp = item.icon;
              const isActive = activePortalIndex === idx;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActivePortalIndex(idx);
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full flex items-center gap-3 text-left text-xs font-bold px-4 py-2.5 rounded-xl transition-all duration-150 ${
                    isActive 
                      ? "bg-[#1E293B] text-white shadow-md" 
                      : "text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100/80 border border-transparent"
                  }`}
                >
                  <IconComp className={`w-4 h-4 ${isActive ? "text-emerald-400" : "text-neutral-400"}`} />
                  <span className="flex-1">{item.label}</span>
                  {isActive && <span className="w-2 h-2 bg-emerald-500 rounded-full" />}
                </button>
              );
            })}
            
            {/* Display active state of user in mobile drawer */}
            {currentUser && (
              <div className="mt-2 pt-3 border-t border-neutral-100 flex items-center justify-between px-2 text-xs">
                <div className="flex flex-col">
                  <span className="font-extrabold text-slate-800">{currentUser.name}</span>
                  <span className="text-[10px] text-neutral-400 leading-none">{getRoleLabel(currentUser.role)}</span>
                </div>
                <button
                  onClick={() => {
                    handleLogout();
                    setMobileMenuOpen(false);
                  }}
                  className="flex items-center gap-1.5 px-3 py-1 text-[10px] font-bold text-rose-700 bg-rose-50 border border-rose-100 rounded-lg"
                >
                  <LogOut className="w-3 h-3" />
                  Sign Out
                </button>
              </div>
            )}
          </div>
        )}
      </header>

      {/* Main Container Wrapper */}
      <main className="w-full max-w-7xl px-4 mt-8 flex-1">

        {/* TAB 1: LANDING HUB */}
        {currentRole === "home" && (
          <div className="flex flex-col gap-12">
            
            {/* Elegant Hero Heading using VideoText */}
            <div className="text-center flex flex-col items-center max-w-4xl mx-auto mt-6">
              <span className="bg-emerald-50 border border-emerald-200/50 text-emerald-800 rounded-full py-1.5 px-4 text-xs font-mono font-extrabold uppercase tracking-widest mb-6 animate-pulse">
                🎓 Next-Gen Campus Placement Architecture
              </span>
              
              <h1 className="sr-only">AI Placement Drive Ecosystem</h1>
              
              <VideoText 
                src="https://assets.mixkit.co/videos/preview/mixkit-circuit-board-digital-animation-431-large.mp4"
                fontSize={8.5}
                fontWeight="black"
                fontFamily="Georgia, serif"
                className="w-full h-[150px] md:h-[220px]"
              >
                PLACEPRO AI
              </VideoText>

              <p className="font-serif text-lg md:text-xl text-[#4A5568] leading-relaxed mt-6 max-w-2xl px-4">
                Automated ATS Resume audit metrics, real-time Gemini corporate mock panels, and placement officers drives scheduled beautifully under one soft academic environment.
              </p>

              <div className="flex flex-wrap gap-4 mt-8 justify-center">
                <ShimmerButton 
                  onClick={() => {
                    // Go to Student portal view. Auth page will intercept if guest
                    setActivePortalIndex(1);
                  }}
                  className="py-3 px-8 text-sm"
                >
                  Enter Student Portal
                </ShimmerButton>
                
                <button
                  onClick={() => {
                    // Go to Officer portal view.
                    setActivePortalIndex(3);
                  }}
                  className="px-6 py-3 border border-neutral-300 text-[#4A5568] hover:bg-white text-sm font-semibold rounded-full hover:shadow-md transition active:scale-95"
                >
                  Placement Officer Lobby
                </button>
              </div>
            </div>

            {/* Feature Bento Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
              {/* Feature 1 */}
              <BorderGlow 
                borderRadius={20}
                className="p-6 md:p-8 hover:shadow-lg transition-all"
                backgroundColor="#FFFFFF"
              >
                <div className="w-10 h-10 bg-emerald-50 text-emerald-700 rounded-xl flex items-center justify-center mb-4 border border-emerald-100">
                  <Sparkles className="w-5 h-5" />
                </div>
                <h3 className="font-serif text-md font-bold text-slate-800 mb-2">AI ATS Resume Auditing</h3>
                <p className="text-xs text-neutral-500 leading-relaxed">
                  Analyze dynamic vacancies using backend Gemini endpoints. Retrieve quantitative matching scores, detect keyword vacancies, and read tailored layout enhancements.
                </p>
              </BorderGlow>

              {/* Feature 2 */}
              <BorderGlow 
                borderRadius={20}
                className="p-6 md:p-8 hover:shadow-lg transition-all"
                backgroundColor="#FFFFFF"
              >
                <div className="w-10 h-10 bg-indigo-50 text-indigo-700 rounded-xl flex items-center justify-center mb-4 border border-indigo-100">
                  <GraduationCap className="w-5 h-5" />
                </div>
                <h3 className="font-serif text-md font-bold text-slate-800 mb-2">AI Mock Panel Terminals</h3>
                <p className="text-xs text-neutral-500 leading-relaxed">
                  Run simulated 5-question technical, HR, or behavioral interviewer rounds. Paste text answers and obtain robust analytical grades matching corporate standards.
                </p>
              </BorderGlow>

              {/* Feature 3 */}
              <BorderGlow 
                borderRadius={20}
                className="p-6 md:p-8 hover:shadow-lg transition-all"
                backgroundColor="#FFFFFF"
              >
                <div className="w-10 h-10 bg-rose-50 text-rose-700 rounded-xl flex items-center justify-center mb-4 border border-rose-100">
                  <Users className="w-5 h-5" />
                </div>
                <h3 className="font-serif text-md font-bold text-slate-800 mb-2">Multi-Role Cooperation</h3>
                <p className="text-xs text-neutral-500 leading-relaxed">
                  Continuous workflow connects student builders, corporate recruiters approving openings, campus officers verifying profiles, and root superuser log monitoring.
                </p>
              </BorderGlow>
            </div>

            {/* Quick Metrics SVG Diagram Block */}
            <div className="bg-white rounded-3xl p-6 md:p-10 border border-neutral-200/50 shadow-sm flex flex-col md:flex-row items-center gap-8 justify-between">
              <div>
                <span className="text-[10px] uppercase font-mono tracking-widest font-bold text-emerald-800 bg-[#E5EEE4] border border-[#A5C89E] py-1 px-3 rounded-full">
                  Verified Campus Milestones
                </span>
                <h2 className="font-serif text-xl md:text-2xl font-bold text-slate-800 mt-4 leading-snug">
                  Uniting verified pipelines with zero mock databases.
                </h2>
                <p className="text-xs text-neutral-500 mt-2 max-w-lg leading-relaxed">
                  Our algorithm cross-checks credentials locally, feeding candidates straight into recruiter lists once college verification seals are authorized by Dean admins.
                </p>
              </div>

              {/* SVG Charts display */}
              <div className="w-full md:w-auto shrink-0 flex gap-4">
                <div className="bg-neutral-50/50 p-5 rounded-2xl border border-neutral-200 text-center flex flex-col items-center">
                  <span className="text-3xl font-serif font-black text-slate-800">120+</span>
                  <span className="text-[10px] text-neutral-400 font-mono uppercase tracking-wider mt-1">Active Students</span>
                </div>
                <div className="bg-neutral-50/50 p-5 rounded-2xl border border-neutral-200 text-center flex flex-col items-center">
                  <span className="text-3xl font-serif font-black text-slate-800">₹12 L</span>
                  <span className="text-[10px] text-neutral-400 font-mono uppercase tracking-wider mt-1">Avg package</span>
                </div>
                <div className="bg-neutral-50/50 p-5 rounded-2xl border border-neutral-200 text-center flex flex-col items-center">
                  <span className="text-3xl font-serif font-black text-slate-800">92%</span>
                  <span className="text-[10px] text-neutral-400 font-mono uppercase tracking-wider mt-1">Hire rate</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* SECURITY GATE 1: GUEST SELECTS A PORTAL -> PROMPT AUTH */}
        {!currentRole !== true && currentRole !== "home" && isGuest && (
          <div className="flex flex-col gap-6 animate-fade-in py-4">
            <div className="bg-emerald-50 border border-emerald-100 text-emerald-950 p-5 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-4 max-w-4xl mx-auto w-full">
              <div className="flex items-start gap-3">
                <Lock className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-serif font-bold text-slate-800 text-sm">Role Authentication Guard</h4>
                  <p className="text-xs text-neutral-600 mt-1">
                    To access the <strong className="capitalize">{currentRole} portal</strong>, please authenticate or spawn a dynamic simulation session using our credentials library below.
                  </p>
                </div>
              </div>
            </div>

            <AuthPage 
              onLoginSuccess={(session) => {
                setCurrentUser(session);
              }}
              onSignupStudent={handleAddStudentOnSignup}
              initialRoleTab={routeRoleMapping[currentRole]}
            />
          </div>
        )}

        {/* SECURITY GATE 2: USER LOGGED IN BUT CLICKS A DIFFERENT PORTAL TAB */}
        {!currentRole !== true && currentRole !== "home" && !isGuest && !isCorrectRole && (
          <div className="flex flex-col items-center justify-center max-w-2xl mx-auto text-center py-12 px-4 animate-fade-in">
            <BorderGlow borderRadius={32} className="bg-white p-8 border border-neutral-200 shadow-lg w-full flex flex-col items-center">
              <div className="w-16 h-16 bg-rose-50 text-rose-700 rounded-full flex items-center justify-center mb-6">
                <AlertTriangle className="w-8 h-8" />
              </div>
              
              <span className="bg-rose-50 border border-rose-200 text-rose-800 rounded-full py-1 px-3 text-[10px] font-mono tracking-widest font-extrabold uppercase">
                Active Session Conflict
              </span>

              <h2 className="font-serif text-2xl font-bold text-slate-800 mt-4 leading-tight">
                Authorized Role Conflict
              </h2>

              <p className="text-sm text-neutral-500 mt-3 leading-relaxed max-w-md">
                You are currently signed in as <strong className="text-slate-800 font-bold">{currentUser.name}</strong> ({getRoleLabel(currentUser.role)}). 
                To open the <strong className="capitalize text-slate-800">{currentRole} portal</strong>, you can switch mode below or log out.
              </p>

              {/* Action buttons */}
              <div className="flex flex-col sm:flex-row gap-3.5 mt-8 w-full">
                <button
                  onClick={() => {
                    // Swap role instantly for quick-testing! Excellent UX
                    const targetRole = routeRoleMapping[currentRole];
                    if (targetRole === "student") {
                      setCurrentUser({
                        id: "stud_1",
                        name: "Aarav Sharma",
                        email: "aarav.sharma@collegetech.edu",
                        role: "student"
                      });
                    } else if (targetRole === "recruiter") {
                      setCurrentUser({
                        id: "rec_1",
                        name: "Google Recruiter (India)",
                        email: "recruitment@google.com",
                        role: "recruiter",
                        companyName: "Google India"
                      });
                    } else if (targetRole === "placementOfficer") {
                      setCurrentUser({
                        id: "off_1",
                        name: "Prof. Rajesh Mehra",
                        email: "placement.officer@collegetech.edu",
                        role: "placementOfficer"
                      });
                    } else if (targetRole === "admin") {
                      setCurrentUser({
                        id: "adm_1",
                        name: "System Super Administrator",
                        email: "admin.root@collegetech.edu",
                        role: "admin"
                      });
                    }
                  }}
                  className="flex-1 flex items-center justify-center gap-2 px-5 py-3 border border-neutral-300 hover:bg-neutral-50 text-xs font-semibold rounded-full transition active:scale-95"
                >
                  <ArrowLeftRight className="w-4 h-4 text-emerald-700" />
                  Auto-switch to {getRoleLabel(routeRoleMapping[currentRole])}
                </button>

                <button
                  onClick={handleLogout}
                  className="flex-1 px-5 py-3 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold font-mono tracking-wider uppercase rounded-full shadow-md transition active:scale-95"
                >
                  Logout Current Session
                </button>
              </div>

              <button
                onClick={() => setActivePortalIndex(0)} // Return to home safely
                className="text-xs text-neutral-400 hover:text-neutral-700 font-medium underline mt-6 underline-offset-4"
              >
                Or, return safe to Landing Hub base
              </button>
            </BorderGlow>
          </div>
        )}

        {/* SECURITY GATE 3: RENDER THE CORRECT MODULES ONCE VERIFIED AND ALIGNED */}
        {!isGuest && isCorrectRole && (
          <div className="animate-fade-in">
            {/* TAB 2: STUDENT PORTAL PANEL */}
            {currentRole === "student" && (
              <StudentProfilePortalWrapper 
                profile={loggedInStudent}
                jobs={jobsByState}
                applications={applicationsByState}
                mockInterviews={mockInterviewsByState}
                onUpdateProfile={handleUpdateStudentProfile}
                onApplyJob={handleApplyJob}
                onSaveMockResult={handleSaveMockInterviewResult}
              />
            )}

            {/* TAB 3: RECRUITER PORTAL PANEL */}
            {currentRole === "recruiter" && (
              <RecruiterPortal 
                jobs={jobsByState}
                applications={applicationsByState}
                students={studentsByState}
                recruiterId={currentUser.id}
                recruiterName={currentUser.companyName || currentUser.name}
                onCreateJob={handleCreateJob}
                onUpdateJob={handleUpdateJob}
                onDeleteJob={handleDeleteJob}
                onUpdateApplicationStatus={handleUpdateApplicationStatus}
              />
            )}

            {/* TAB 4: PLACEMENT OFFICER PANEL */}
            {currentRole === "officer" && (
              <PlacementOfficerPortal 
                students={studentsByState}
                jobs={jobsByState}
                drives={drivesByState}
                onVerifyStudent={handleVerifyStudent}
                onVerifyJob={handleVerifyJob}
                onAddDrive={handleAddDrive}
                onDeleteDrive={handleDeleteDrive}
              />
            )}

            {/* TAB 5: ADMIN PORTAL PANEL */}
            {currentRole === "admin" && (
              <AdminPortal 
                students={studentsByState}
                jobs={jobsByState}
                applications={applicationsByState}
                onDeleteStudent={handleDeleteStudent}
                onGrantVerification={handleGrantVerification}
                onClearCache={handleClearCache}
              />
            )}
          </div>
        )}
      </main>
    </div>
  );
}

// Subwrapper to encapsulate StudentPortal cleanly
function StudentProfilePortalWrapper({
  profile,
  jobs,
  applications,
  mockInterviews,
  onUpdateProfile,
  onApplyJob,
  onSaveMockResult
}: {
  profile: StudentProfile;
  jobs: Job[];
  applications: Application[];
  mockInterviews: MockInterviewResult[];
  onUpdateProfile: (updated: StudentProfile) => void;
  onApplyJob: (jobId: string) => void;
  onSaveMockResult: (result: MockInterviewResult) => void;
}) {
  return (
    <StudentPortal 
      profile={profile}
      jobs={jobs}
      applications={applications}
      mockInterviews={mockInterviews}
      onUpdateProfile={onUpdateProfile}
      onApplyJob={onApplyJob}
      onSaveMockResult={onSaveMockResult}
    />
  );
}

