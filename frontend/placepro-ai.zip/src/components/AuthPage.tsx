import React, { useState } from "react";
import { 
  Sparkles, Shield, User, Briefcase, GraduationCap, Users, 
  ArrowRight, Key, Mail, Phone, Code, BookOpen, Clock, LogIn, UserPlus, Info, CheckCircle2
} from "lucide-react";
import BorderGlow from "./BorderGlow";
import ShimmerButton from "./ShimmerButton";
import { StudentProfile, UserRole } from "../types";

interface AuthPageProps {
  onLoginSuccess: (session: {
    id: string;
    name: string;
    email: string;
    role: UserRole;
    companyName?: string;
  }) => void;
  onSignupStudent: (newStudent: StudentProfile) => void;
  onClose?: () => void;
  initialRoleTab?: UserRole;
}

export default function AuthPage({ 
  onLoginSuccess, 
  onSignupStudent,
  onClose,
  initialRoleTab = "student"
}: AuthPageProps) {
  const [authMode, setAuthMode] = useState<"signin" | "signup">("signin");
  const [selectedRole, setSelectedRole] = useState<UserRole>(initialRoleTab);

  // Common fields
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");

  // Student specific signup fields
  const [phone, setPhone] = useState("+91 ");
  const [linkedin, setLinkedin] = useState("https://linkedin.com/in/");
  const [github, setGithub] = useState("https://github.com/");
  const [degree, setDegree] = useState("B.Tech");
  const [major, setMajor] = useState("Computer Science");
  const [gradYear, setGradYear] = useState("2026");
  const [cgpa, setCgpa] = useState("8.5");

  // Recruiter specific fields
  const [companyName, setCompanyName] = useState("");
  const [location, setLocation] = useState("Bangalore (Onsite)");

  // Coordinator/Admin passcodes
  const [officerPasscode, setOfficerPasscode] = useState("");
  const [adminPasscode, setAdminPasscode] = useState("");

  // Error/Success state feedback
  const [errorMessage, setErrorMessage] = useState("");
  const [successMessage, setSuccessMessage] = useState("");

  const handleRoleChange = (role: UserRole) => {
    setSelectedRole(role);
    setErrorMessage("");
    setSuccessMessage("");
  };

  const handleModeChange = (mode: "signin" | "signup") => {
    setAuthMode(mode);
    setErrorMessage("");
    setSuccessMessage("");
  };

  // Demo Login Quick-handlers (Preseeded data reference)
  const triggerDemoLogin = (type: "aarav" | "aditi" | "rohan" | "google" | "microsoft" | "officer" | "admin") => {
    setErrorMessage("");
    if (type === "aarav") {
      onLoginSuccess({
        id: "stud_1",
        name: "Aarav Sharma",
        email: "aarav.sharma@collegetech.edu",
        role: "student"
      });
    } else if (type === "aditi") {
      onLoginSuccess({
        id: "stud_2",
        name: "Aditi Iyer",
        email: "aditi.iyer@collegetech.edu",
        role: "student"
      });
    } else if (type === "rohan") {
      onLoginSuccess({
        id: "stud_3",
        name: "Rohan Verma",
        email: "rohan.v@collegetech.edu",
        role: "student"
      });
    } else if (type === "google") {
      onLoginSuccess({
        id: "rec_1",
        name: "Google Recruiter (India)",
        email: "recruitment@google.com",
        role: "recruiter",
        companyName: "Google India"
      });
    } else if (type === "microsoft") {
      onLoginSuccess({
        id: "rec_2",
        name: "Microsoft Recruiting",
        email: "careers@microsoft.com",
        role: "recruiter",
        companyName: "Microsoft Corp"
      });
    } else if (type === "officer") {
      onLoginSuccess({
        id: "off_1",
        name: "Prof. Rajesh Mehra",
        email: "placement.officer@collegetech.edu",
        role: "placementOfficer"
      });
    } else if (type === "admin") {
      onLoginSuccess({
        id: "adm_1",
        name: "System Super Administrator",
        email: "admin.root@collegetech.edu",
        role: "admin"
      });
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage("");
    setSuccessMessage("");

    // Minimal validation
    if (!email.trim() || !password.trim()) {
      setErrorMessage("Please fill out both email and password fields.");
      return;
    }

    if (authMode === "signup") {
      if (!name.trim()) {
        setErrorMessage("Please enter your full name.");
        return;
      }

      if (selectedRole === "student") {
        if (!phone.trim() || !cgpa.trim()) {
          setErrorMessage("Please fill in candidate telephone and CGPA values.");
          return;
        }
        
        // Build a fresh student profile
        const newStudentId = "stud_" + Date.now();
        const freshStudent: StudentProfile = {
          id: newStudentId,
          name: name,
          email: email,
          phone: phone,
          linkedin: linkedin,
          github: github,
          skills: ["React", "JavaScript", "HTML/CSS", "Python"],
          projects: [
            {
              name: "Portfolio Project",
              desc: "Personal webpage detailing academic accomplishments and skills showcase.",
              tech: "React, CSS, Netlify"
            }
          ],
          certifications: ["PlacePro AI Academy Graduate"],
          resumeText: `${name.toUpperCase()} - Software Aspirant\nEmail: ${email} | Phone: ${phone}\nSkills: React, Python, JavaScript\nEducation: ${degree} in ${major} (CGPA: ${cgpa})`,
          academic: {
            degree,
            major,
            institution: "State Engineering College",
            graduationYear: gradYear,
            cgpa
          },
          verificationStatus: "Pending", // Direct pending verify
          resumeScore: 70,
          atsScore: 68,
          readinessScore: 72
        };

        onSignupStudent(freshStudent);
        setSuccessMessage(`Account created! Student profile for ${name} registered. Logging you in...`);
        
        setTimeout(() => {
          onLoginSuccess({
            id: newStudentId,
            name: name,
            email: email,
            role: "student"
          });
        }, 1200);

      } else if (selectedRole === "recruiter") {
        if (!companyName.trim()) {
          setErrorMessage("Please enter your corporate company name.");
          return;
        }
        const recId = "rec_" + Date.now();
        setSuccessMessage(`Registered successfully as recruiter for ${companyName}!`);
        setTimeout(() => {
          onLoginSuccess({
            id: recId,
            name: name,
            email: email,
            role: "recruiter",
            companyName: companyName
          });
        }, 1200);

      } else if (selectedRole === "placementOfficer") {
        if (officerPasscode !== "CAMPUS2026") {
          setErrorMessage("Invalid Coordinator placement office authorization passcode.");
          return;
        }
        setSuccessMessage("Authorized Coordinator successfully!");
        setTimeout(() => {
          onLoginSuccess({
            id: "off_" + Date.now(),
            name: name,
            email: email,
            role: "placementOfficer"
          });
        }, 1000);

      } else if (selectedRole === "admin") {
        if (adminPasscode !== "ADMINROOT") {
          setErrorMessage("Invalid master system administrator secret security phrase.");
          return;
        }
        setSuccessMessage("Root system master access granted.");
        setTimeout(() => {
          onLoginSuccess({
            id: "adm_" + Date.now(),
            name: name,
            email: email,
            role: "admin"
          });
        }, 1000);
      }
    } else {
      // SignIn Simulation
      // Check preseeded credentials
      if (selectedRole === "student") {
        if (email.toLowerCase().includes("aarav") || email.toLowerCase().includes("stud_1")) {
          triggerDemoLogin("aarav");
          return;
        } else if (email.toLowerCase().includes("aditi") || email.toLowerCase().includes("stud_2")) {
          triggerDemoLogin("aditi");
          return;
        } else if (email.toLowerCase().includes("rohan") || email.toLowerCase().includes("stud_3")) {
          triggerDemoLogin("rohan");
          return;
        }
        // General fallback signin
        onLoginSuccess({
          id: "stud_temp_" + Math.floor(Math.random() * 100),
          name: name || "Demo Student",
          email: email,
          role: "student"
        });
      } else if (selectedRole === "recruiter") {
        if (email.toLowerCase().includes("google") || email.toLowerCase().includes("rec_1")) {
          triggerDemoLogin("google");
          return;
        } else if (email.toLowerCase().includes("microsoft") || email.toLowerCase().includes("rec_2")) {
          triggerDemoLogin("microsoft");
          return;
        }
        onLoginSuccess({
          id: "rec_temp",
          name: name || "Recruiter Guest",
          email: email,
          role: "recruiter",
          companyName: companyName || "Enterprise Guest Inc"
        });
      } else if (selectedRole === "placementOfficer") {
        onLoginSuccess({
          id: "off_1",
          name: "Prof. Rajesh Mehra",
          email: email,
          role: "placementOfficer"
        });
      } else if (selectedRole === "admin") {
        onLoginSuccess({
          id: "adm_1",
          name: "System Super Administrator",
          email: email,
          role: "admin"
        });
      }
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto py-4">
      <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
        
        {/* Left column: Login / Register Panel */}
        <div className="md:col-span-7 flex flex-col">
          <BorderGlow borderRadius={24} className="bg-white p-6 md:p-8 shadow-sm border border-neutral-200/50">
            {/* Tab selection for Sign In / Sign Up */}
            <div className="flex bg-neutral-100 p-1.5 rounded-full mb-6">
              <button
                type="button"
                onClick={() => handleModeChange("signin")}
                className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 text-xs font-mono font-extrabold rounded-full transition-all ${
                  authMode === "signin"
                    ? "bg-white text-slate-800 shadow-sm"
                    : "text-neutral-500 hover:text-neutral-800"
                }`}
              >
                <LogIn className="w-3.5 h-3.5" />
                SIGN IN
              </button>
              <button
                type="button"
                onClick={() => handleModeChange("signup")}
                className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 text-xs font-mono font-extrabold rounded-full transition-all ${
                  authMode === "signup"
                    ? "bg-white text-slate-800 shadow-sm"
                    : "text-neutral-500 hover:text-neutral-800"
                }`}
              >
                <UserPlus className="w-3.5 h-3.5" />
                CREATE ACCOUNT
              </button>
            </div>

            <div className="mb-6 text-center">
              <h2 className="text-xl font-serif font-bold text-slate-800">
                {authMode === "signin" ? "Access PlacePro AI Gateway" : "Register Your Campus Role"}
              </h2>
              <p className="text-xs text-neutral-400 mt-1.5">
                {authMode === "signin" 
                  ? "Select your operational role and input credentials." 
                  : "Pick your portal path and create a functional record profile."}
              </p>
            </div>

            {/* Role Tab bar */}
            <div className="flex justify-around gap-2 p-1 bg-neutral-50 rounded-xl mb-6 border border-neutral-100">
              <button
                type="button"
                onClick={() => handleRoleChange("student")}
                className={`flex-1 flex flex-col items-center gap-1 py-2 rounded-lg transition-all ${
                  selectedRole === "student"
                    ? "bg-white border border-neutral-200 text-emerald-800 font-semibold"
                    : "text-neutral-400 hover:text-neutral-600"
                }`}
              >
                <GraduationCap className="w-4 h-4" />
                <span className="text-[10px] font-mono tracking-wider font-extrabold uppercase">Student</span>
              </button>

              <button
                type="button"
                onClick={() => handleRoleChange("recruiter")}
                className={`flex-1 flex flex-col items-center gap-1 py-2 rounded-lg transition-all ${
                  selectedRole === "recruiter"
                    ? "bg-white border border-neutral-200 text-indigo-800 font-semibold"
                    : "text-neutral-400 hover:text-neutral-600"
                }`}
              >
                <Briefcase className="w-4 h-4" />
                <span className="text-[10px] font-mono tracking-wider font-extrabold uppercase">Recruiter</span>
              </button>

              <button
                type="button"
                onClick={() => handleRoleChange("placementOfficer")}
                className={`flex-1 flex flex-col items-center gap-1 py-2 rounded-lg transition-all ${
                  selectedRole === "placementOfficer"
                    ? "bg-white border border-neutral-200 text-rose-800 font-semibold"
                    : "text-neutral-400 hover:text-neutral-600"
                }`}
              >
                <Users className="w-4 h-4" />
                <span className="text-[10px] font-mono tracking-wider font-extrabold uppercase">Officer</span>
              </button>

              <button
                type="button"
                onClick={() => handleRoleChange("admin")}
                className={`flex-1 flex flex-col items-center gap-1 py-2 rounded-lg transition-all ${
                  selectedRole === "admin"
                    ? "bg-white border border-neutral-200 text-amber-800 font-semibold"
                    : "text-neutral-400 hover:text-neutral-600"
                }`}
              >
                <Shield className="w-4 h-4" />
                <span className="text-[10px] font-mono tracking-wider font-extrabold uppercase">Admin</span>
              </button>
            </div>

            {/* Error Message */}
            {errorMessage && (
              <div className="bg-rose-50 border border-rose-200 text-rose-800 rounded-xl p-3.5 text-xs font-semibold mb-6 flex items-start gap-2.5 animate-shake">
                <span className="w-2.5 h-2.5 bg-rose-500 rounded-full shrink-0 mt-0.5" />
                <span>{errorMessage}</span>
              </div>
            )}

            {/* Success Message */}
            {successMessage && (
              <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl p-3.5 text-xs font-semibold mb-6 flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <span>{successMessage}</span>
              </div>
            )}

            {/* Form */}
            <form onSubmit={handleSubmit} className="flex flex-col gap-4">
              
              {authMode === "signup" && (
                <div className="flex flex-col gap-1">
                  <label className="text-xs font-mono font-extrabold tracking-wider text-slate-600 uppercase">
                    Full Name
                  </label>
                  <div className="relative">
                    <User className="absolute left-3 top-3 w-4 h-4 text-neutral-400" />
                    <input
                      type="text"
                      placeholder="e.g. Vikram Singh"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full pl-9 pr-4 py-2.5 text-sm bg-neutral-50/50 border border-neutral-200 rounded-xl focus:outline-none focus:border-neutral-400 focus:bg-white"
                      required
                    />
                  </div>
                </div>
              )}

              <div className="flex flex-col gap-1">
                <label className="text-xs font-mono font-extrabold tracking-wider text-slate-600 uppercase">
                  College / Professional Email
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-3 w-4 h-4 text-neutral-400" />
                  <input
                    type="email"
                    placeholder="e.g. student@collegetech.edu"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full pl-9 pr-4 py-2.5 text-sm bg-neutral-50/50 border border-neutral-200 rounded-xl focus:outline-none focus:border-neutral-400 focus:bg-white"
                    required
                  />
                </div>
              </div>

              <div className="flex flex-col gap-1">
                <label className="text-xs font-mono font-extrabold tracking-wider text-slate-600 uppercase">
                  Password
                </label>
                <div className="relative">
                  <Key className="absolute left-3 top-3 w-4 h-4 text-neutral-400" />
                  <input
                    type="password"
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full pl-9 pr-4 py-2.5 text-sm bg-neutral-50/50 border border-neutral-200 rounded-xl focus:outline-none focus:border-neutral-400 focus:bg-white"
                    required
                  />
                </div>
              </div>

              {/* Dynamic signup subforms based on selected role */}
              {authMode === "signup" && selectedRole === "student" && (
                <div className="border-t border-neutral-100 pt-4 mt-2 flex flex-col gap-4 animate-fade-in">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="flex flex-col gap-1">
                      <label className="text-xs font-mono font-extrabold tracking-wider text-slate-600 uppercase">
                        Phone Number
                      </label>
                      <input
                        type="text"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        className="w-full px-3 py-2 text-sm bg-neutral-50/50 border border-neutral-200 rounded-xl"
                      />
                    </div>
                    <div className="flex flex-col gap-1">
                      <label className="text-xs font-mono font-extrabold tracking-wider text-slate-600 uppercase">
                        Current CGPA
                      </label>
                      <input
                        type="number"
                        step="0.01"
                        max="10"
                        min="0"
                        value={cgpa}
                        onChange={(e) => setCgpa(e.target.value)}
                        className="w-full px-3 py-2 text-sm bg-neutral-50/50 border border-neutral-200 rounded-xl"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="flex flex-col gap-1">
                      <label className="text-xs font-mono font-extrabold tracking-wider text-slate-600 uppercase">
                        Academic Degree
                      </label>
                      <select
                        value={degree}
                        onChange={(e) => setDegree(e.target.value)}
                        className="w-full px-3 py-2 text-sm bg-neutral-50/50 border border-neutral-200 rounded-xl"
                      >
                        <option value="B.Tech">B.Tech</option>
                        <option value="M.Tech">M.Tech</option>
                        <option value="MCA">MCA</option>
                        <option value="BCA">BCA</option>
                      </select>
                    </div>
                    <div className="flex flex-col gap-1">
                      <label className="text-xs font-mono font-extrabold tracking-wider text-slate-600 uppercase">
                        Branch / Major
                      </label>
                      <input
                        type="text"
                        value={major}
                        onChange={(e) => setMajor(e.target.value)}
                        className="w-full px-3 py-2 text-sm bg-neutral-50/50 border border-neutral-200 rounded-xl"
                      />
                    </div>
                  </div>

                  <div className="flex flex-col gap-1">
                    <label className="text-xs font-mono font-extrabold tracking-wider text-slate-600 uppercase">
                      LinkedIn URL
                    </label>
                    <input
                      type="text"
                      value={linkedin}
                      onChange={(e) => setLinkedin(e.target.value)}
                      className="w-full px-3 py-2 text-sm bg-neutral-50/50 border border-neutral-200 rounded-xl"
                    />
                  </div>

                  <div className="flex flex-col gap-1">
                    <label className="text-xs font-mono font-extrabold tracking-wider text-slate-600 uppercase">
                      GitHub URL
                    </label>
                    <input
                      type="text"
                      value={github}
                      onChange={(e) => setGithub(e.target.value)}
                      className="w-full px-3 py-2 text-sm bg-neutral-50/50 border border-neutral-200 rounded-xl"
                    />
                  </div>
                </div>
              )}

              {authMode === "signup" && selectedRole === "recruiter" && (
                <div className="border-t border-neutral-100 pt-4 mt-2 flex flex-col gap-4 animate-fade-in">
                  <div className="flex flex-col gap-1">
                    <label className="text-xs font-mono font-extrabold tracking-wider text-slate-600 uppercase">
                      Company Name
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Netflix India"
                      value={companyName}
                      onChange={(e) => setCompanyName(e.target.value)}
                      className="w-full px-3 py-2.5 text-sm bg-neutral-50/50 border border-neutral-200 rounded-xl"
                      required
                    />
                  </div>
                  <div className="flex flex-col gap-1">
                    <label className="text-xs font-mono font-extrabold tracking-wider text-slate-600 uppercase">
                      Hiring Headquarters Location
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Mumbai (Onsite)"
                      value={location}
                      onChange={(e) => setLocation(e.target.value)}
                      className="w-full px-3 py-2.5 text-sm bg-neutral-50/50 border border-neutral-200 rounded-xl"
                    />
                  </div>
                </div>
              )}

              {authMode === "signup" && selectedRole === "placementOfficer" && (
                <div className="border-t border-neutral-100 pt-4 mt-2 flex flex-col gap-4 animate-fade-in">
                  <div className="flex flex-col gap-1 bg-[#FAFAF5] p-3 rounded-lg border border-neutral-200/50">
                    <div className="flex items-center gap-1 text-emerald-800 font-mono text-[10px] uppercase font-bold mb-1">
                      <Info className="w-3.5 h-3.5 text-emerald-700" />
                      Coordinator Office Credentials Required
                    </div>
                    <p className="text-[11px] text-neutral-500 leading-relaxed mb-2">
                      Please enter the authorization passkey issued by the college board. (Demo key: <code className="font-mono bg-neutral-200 px-1 rounded text-[#222]">CAMPUS2026</code>)
                    </p>
                    <input
                      type="password"
                      placeholder="Enter Campus passkey"
                      value={officerPasscode}
                      onChange={(e) => setOfficerPasscode(e.target.value)}
                      className="w-full px-3 py-2 text-sm bg-white border border-neutral-200 rounded-xl"
                      required
                    />
                  </div>
                </div>
              )}

              {authMode === "signup" && selectedRole === "admin" && (
                <div className="border-t border-neutral-100 pt-4 mt-2 flex flex-col gap-4 animate-fade-in">
                  <div className="flex flex-col gap-1 bg-[#FAFAF5] p-3 rounded-lg border border-neutral-200/50">
                    <div className="flex items-center gap-1 text-amber-800 font-mono text-[10px] uppercase font-bold mb-1">
                      <Info className="w-3.5 h-3.5 text-amber-700" />
                      Root Admin Credentials Required
                    </div>
                    <p className="text-[11px] text-neutral-500 leading-relaxed mb-2">
                      Enter the master root password to spin up administrator authority. (Demo key: <code className="font-mono bg-neutral-200 px-1 rounded text-[#222]">ADMINROOT</code>)
                    </p>
                    <input
                      type="password"
                      placeholder="Enter Root master key"
                      value={adminPasscode}
                      onChange={(e) => setAdminPasscode(e.target.value)}
                      className="w-full px-3 py-2 text-sm bg-white border border-neutral-200 rounded-xl"
                      required
                    />
                  </div>
                </div>
              )}

              <ShimmerButton type="submit" className="py-3 px-8 text-sm w-full mt-2 font-mono uppercase font-black">
                {authMode === "signin" ? `Sign In as ${selectedRole}` : `Complete ${selectedRole} Registration`}
              </ShimmerButton>

              {onClose && (
                <button
                  type="button"
                  onClick={onClose}
                  className="w-full text-center text-xs text-neutral-500 hover:text-neutral-800 py-1"
                >
                  Cancel and Return
                </button>
              )}
            </form>
          </BorderGlow>
        </div>

        {/* Right column: Quick demo login card dashboard */}
        <div className="md:col-span-5 flex flex-col gap-4">
          <div className="bg-[#FAF9F3] p-5 rounded-3xl border border-neutral-200 flex flex-col gap-4">
            <div className="flex items-center gap-2 text-slate-800 font-serif font-bold text-sm">
              <Sparkles className="w-4 h-4 text-emerald-700 shrink-0" />
              <span>One-Click Testing Accounts</span>
            </div>
            <p className="text-[11px] text-neutral-500 leading-relaxed">
              We pre-loaded test database users mapping each specialized dashboard framework role. Select a credentials pill below to log in instantly.
            </p>

            <div className="flex flex-col gap-3 mt-1">
              
              {/* Students quickies */}
              <div>
                <span className="text-[9px] font-mono font-bold tracking-wider text-neutral-400 uppercase">STUDENTS (PRE-LOADED PROFILES)</span>
                <div className="flex flex-col gap-2 mt-1.5">
                  <button
                    onClick={() => triggerDemoLogin("aarav")}
                    className="flex items-center justify-between p-2 text-xs bg-white hover:bg-neutral-100/50 border border-neutral-200 rounded-xl transition text-left"
                  >
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-full bg-emerald-50 text-emerald-800 flex items-center justify-center font-bold text-[10px]">
                        AS
                      </div>
                      <div>
                        <div className="font-semibold text-slate-800">Aarav Sharma</div>
                        <div className="text-[9px] text-neutral-400 font-mono">B.Tech CSE (Verified)</div>
                      </div>
                    </div>
                    <ArrowRight className="w-3 h-3 text-neutral-400 mr-1" />
                  </button>

                  <button
                    onClick={() => triggerDemoLogin("aditi")}
                    className="flex items-center justify-between p-2 text-xs bg-white hover:bg-neutral-100/50 border border-neutral-200 rounded-xl transition text-left"
                  >
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-full bg-emerald-50 text-emerald-800 flex items-center justify-center font-bold text-[10px]">
                        AI
                      </div>
                      <div>
                        <div className="font-semibold text-slate-800">Aditi Iyer</div>
                        <div className="text-[9px] text-neutral-400 font-mono">B.Tech IT (Pending)</div>
                      </div>
                    </div>
                    <ArrowRight className="w-3 h-3 text-neutral-400 mr-1" />
                  </button>
                </div>
              </div>

              {/* Recruiter quickies */}
              <div className="pt-2 border-t border-neutral-200/50">
                <span className="text-[9px] font-mono font-bold tracking-wider text-neutral-400 uppercase">RECRUITERS</span>
                <div className="flex flex-col gap-2 mt-1.5">
                  <button
                    onClick={() => triggerDemoLogin("google")}
                    className="flex items-center justify-between p-2 text-xs bg-white hover:bg-neutral-100/50 border border-neutral-200 rounded-xl transition text-left"
                  >
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-full bg-indigo-50 text-indigo-800 flex items-center justify-center font-bold text-[10px]">
                        G
                      </div>
                      <div>
                        <div className="font-semibold text-slate-800">Google India</div>
                        <div className="text-[9px] text-neutral-400 font-mono">Company recruiter</div>
                      </div>
                    </div>
                    <ArrowRight className="w-3 h-3 text-neutral-400 mr-1" />
                  </button>
                </div>
              </div>

              {/* Placement Officer & Root Admin */}
              <div className="pt-2 border-t border-neutral-200/50">
                <span className="text-[9px] font-mono font-bold tracking-wider text-neutral-400 uppercase">FINANCIALS / AUTHORITY</span>
                <div className="flex flex-col gap-2 mt-1.5">
                  <button
                    onClick={() => triggerDemoLogin("officer")}
                    className="flex items-center justify-between p-2 text-xs bg-white hover:bg-neutral-100/50 border border-neutral-200 rounded-xl transition text-left"
                  >
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-full bg-rose-50 text-rose-800 flex items-center justify-center font-bold text-[10px]">
                        PO
                      </div>
                      <div>
                        <div className="font-semibold text-slate-800">Prof. Rajesh Mehra</div>
                        <div className="text-[9px] text-neutral-400 font-mono">Placement Coordinator</div>
                      </div>
                    </div>
                    <ArrowRight className="w-3 h-3 text-neutral-400 mr-1" />
                  </button>

                  <button
                    onClick={() => triggerDemoLogin("admin")}
                    className="flex items-center justify-between p-2 text-xs bg-white hover:bg-neutral-100/50 border border-neutral-200 rounded-xl transition text-left"
                  >
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-full bg-amber-50 text-amber-800 flex items-center justify-center font-bold text-[10px]">
                        AD
                      </div>
                      <div>
                        <div className="font-semibold text-slate-800">System Admin</div>
                        <div className="text-[9px] text-neutral-400 font-mono">Full Platform Audit</div>
                      </div>
                    </div>
                    <ArrowRight className="w-3 h-3 text-neutral-400 mr-1" />
                  </button>
                </div>
              </div>

            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
